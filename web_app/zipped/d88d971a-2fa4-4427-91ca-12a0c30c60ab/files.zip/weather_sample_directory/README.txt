This is a project for analyzing weather data.
- run the weather_reading.py script
- use weather_processing.PY to process the data
